
Development environment: Windows 7 + Keil version 5+ JTAG debugger