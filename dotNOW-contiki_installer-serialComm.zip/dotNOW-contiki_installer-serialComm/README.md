# emote

This project is aimed to develop emote board bootloader and Linux-based flashing program.

There are three sub-projects in three separate folders.

1. Emoteboot, emote board bootloader project( running with Windows+Keil development environments)

2. Emoteflash, flashing program (running in Ubuntu)

3. APP_HELLO, hello world program, contiki system can refer it to use UART port and read mote it (running with Windows+Keil development environments)

If you would like to customize these programs, you can find all source codes in the corresponding folders; otherwise, you can obtain all installation files via the folder /emoteinstall. 
More development and installation details can be found in readme.txt files located in each individual folder. 
