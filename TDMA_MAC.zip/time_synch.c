/****************************************Copyright (c)****************************************************
**                                ������6lowpan���߿���ƽ̨
**                                  һ��Ϊ��ԴӦ�ö���
**
**
**--------------File Info---------------------------------------------------------------------------------
** File Name:               time_synch.c
** Last modified Date:      2016-06-14
** Last Version:            V1.0
** Description:             ��ʱ��ͬ������

**--------------------------------------------------------------------------------------------------------
** Created By:              �κ���
** Created date:            2016-06-14
** Version:                 V1.0
** Descriptions:            The original version ��ʼ�汾
**
**--------------------------------------------------------------------------------------------------------
** Modified by:
** Modified date:
** Version:
** Description:
**
*********************************************************************************************************/
#include <contiki.h>
#include "time_synch.h"

/*********************************************************************************************************
** ȫ�ֱ�������
*********************************************************************************************************/
static uint8_t __authority_level = 0xFF;

/*********************************************************************************************************
** Function name:       time_synch_authority_level
** Descriptions:        ����ʱ��ͬ������
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��ȡ���ĵ�ǰͬ������
*********************************************************************************************************/
uint8_t time_synch_authority_level(void)
{
  return __authority_level;
}

/*********************************************************************************************************
** Function name:       time_synch_authority_level
** Descriptions:        ����ʱ��ͬ������
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��ȡ���ĵ�ǰͬ������
*********************************************************************************************************/
void time_synch_set_authority_level(uint8_t level)
{
  uint8_t old_level = __authority_level;

  __authority_level = level;

  if(old_level != __authority_level) {
    return;
  }
}

/*********************************************************************************************************
** Function name:       time_synch_authority_level
** Descriptions:        ����ʱ��ͬ������
** input parameters:    time: ʱ�����
**                      factor�� ����ϵ��
** output parameters:   ��
** Returned value:      ��ȡ���ĵ�ǰͬ������
*********************************************************************************************************/
void time_synch_set_rtime(struct timestamp *time, uint32_t  factor)
{
  if(time->authority_level >= __authority_level) {
     return;
  }
  
  rtimer_arch_set(time->time, factor);
}

/*********************************************************************************************************
** Function name:       time_synch_set_diff
** Descriptions:        ����ʱ��ͬ������
** input parameters:    time: ʱ�����
**                      now: ��ǰʱ��
** output parameters:   ��
** Returned value:      ��ȡ���ĵ�ǰͬ������
*********************************************************************************************************/
void time_synch_set_diff(struct timestamp *time, uint32_t  now)
{
  if(time->authority_level >= __authority_level) {
     return;
  }
  
  rtimer_diff_set(time->time, now);
}
/*********************************************************************************************************
  END FILE
*********************************************************************************************************/