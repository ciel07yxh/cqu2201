/****************************************Copyright (c)****************************************************
**                                ������6lowpan���߿���ƽ̨
**                                  һ��Ϊ��ԴӦ�ö���
**
**
**--------------File Info---------------------------------------------------------------------------------
** File Name:               tdma_mac.c
** Last modified Date:      2016-06-14
** Last Version:            V1.0
** Description:             TDMAʱ϶����mac�����㷨

**--------------------------------------------------------------------------------------------------------
** Created By:              �κ���
** Created date:            2016-06-14
** Version:                 V1.0
** Descriptions:            The original version ��ʼ�汾
**
**--------------------------------------------------------------------------------------------------------
** Modified by:
** Modified date:
** Version:
** Description:
**
*********************************************************************************************************/
#include "contiki.h"
#include "net/tdma_mac.h"
#include "net/netstack.h"
#include "net/ip/uip.h"
#include "net/ip/tcpip.h"
#include "net/packetbuf.h"
#include "net/queuebuf.h"
#include "sys/rtimer.h"
#include "lib/memb.h"
#include "lib/list.h"
#include "dev/leds.h"
#include "node-id.h"

#include <string.h>
#include <stdio.h>

/*********************************************************************************************************
  ���Թ�������
*********************************************************************************************************/
#define DEBUG 0
#if DEBUG
#define PRINTF(...)             printf(__VA_ARGS__)
#else
#define PRINTF(...)
#endif

/*********************************************************************************************************
  TDMA configuration 
*********************************************************************************************************/
#define PERIOD_LENGTH   RTIMER_SECOND

#define NR_SLOTS        4
#define SLOT_LENGTH     (PERIOD_LENGTH / NR_SLOTS)
#define GUARD_PERIOD    (PERIOD_LENGTH / 20)
#define MY_SLOT         (node_id % NR_SLOTS)


/*********************************************************************************************************
  Buffers 
*********************************************************************************************************/
#define MAX_QUEUED_PACKETS      QUEUEBUF_NUM
MEMB(packet_memb, struct rdc_buf_list, MAX_QUEUED_PACKETS);
LIST(rdc_buf_list);

/*********************************************************************************************************
  ȫ�ֱ�������
*********************************************************************************************************/
static struct rtimer rtimer;
uint8_t timer_on = 0;
uint8 radio_always_on = 0;

static void radio_off_timer_handle(void *ptr) 
{
  while(NETSTACK_RADIO.receiving_packet());
  NETSTACK_RADIO.off();
}

/*********************************************************************************************************
** Function name:       send_packet
** Descriptions:        mac������send_packet����ʵ��
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
static char
transmitter(struct rtimer *t, void *ptr)
{
  int r;
  uint32_t now, temp;
  static struct ctimer ct;
  mac_callback_t sent = (mac_callback_t)ptr;
  
  struct rdc_buf_list *q = list_head(rdc_buf_list);
  if(q != NULL) {
    /* Send packets in the neighbor's list */
    NETSTACK_RADIO.on();
    NETSTACK_RDC.send(sent, ptr);
    if(!radio_always_on) {
      ctimer_set(&ct, 4,radio_off_timer_handle, NULL);
    }
    
    list_remove(rdc_buf_list, q);
    memb_free(&packet_memb, q);
  }
  
  now = RTIMER_NOW();
  temp = PERIOD_LENGTH - (now % PERIOD_LENGTH) + MY_SLOT * SLOT_LENGTH;
  r = rtimer_set(&rtimer, now + temp, 1,
                 (void (*)(struct rtimer *, void *))transmitter, (void *)sent);
  
  if(r) {
    PRINTF("TIMER Error #3: %d\n", r);
    timer_on = 0;
  }
  
  return 0;
}

/*********************************************************************************************************
** Function name:       send_packet
** Descriptions:        mac������send_packet����ʵ��
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
static void
send_packet(mac_callback_t sent, void *ptr)
{
  int r;
  uint32_t now, temp;
  struct rdc_buf_list *q;
  
  q = memb_alloc(&packet_memb);
  if(q == NULL) {
    return;
  }
  
  q->buf = queuebuf_new_from_packetbuf();
  q->ptr = ptr;
  list_add(rdc_buf_list, q);
  
  /* The packet allocation failed. Remove and free neighbor entry if empty. */
  if(list_length(rdc_buf_list) == 0) {
    list_remove(rdc_buf_list, q);
    memb_free(&packet_memb, q);
  }
  
  if(!timer_on) {
    now = RTIMER_NOW();
    temp = PERIOD_LENGTH - (now % PERIOD_LENGTH) + MY_SLOT * SLOT_LENGTH;
    r = rtimer_set(&rtimer, now + temp, 1,
                   (void (*)(struct rtimer *, void *))transmitter, (void *)sent);
    if(r) {
      PRINTF("TIMER Error #3: %d\n", r);
      timer_on = 0;
    } else {
      timer_on = 1;
    }
  }
}

/*********************************************************************************************************
** Function name:       input_packet
** Descriptions:        mac������input_packet����ʵ��
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��ǰ����Ƶ����״̬
*********************************************************************************************************/
static void
input_packet(void)
{
  NETSTACK_LLSEC.input();
}

/*********************************************************************************************************
** Function name:       on
** Descriptions:        mac������on����ʵ��
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��ǰ����Ƶ����״̬
*********************************************************************************************************/
static int
on(void)
{
  return NETSTACK_RDC.on();
}

/*********************************************************************************************************
** Function name:       off
** Descriptions:        mac������off����ʵ��
** input parameters:    ��
** output parameters:   ��
** Returned value:      �رս��
*********************************************************************************************************/
static int
off(int keep_radio_on)
{
  return NETSTACK_RDC.off(keep_radio_on);
}

/*********************************************************************************************************
** Function name:       channel_check_interval
** Descriptions:        mac������channel_check_interval����ʵ��
** input parameters:    ��
** output parameters:   ��
** Returned value:      �ŵ������
*********************************************************************************************************/
static unsigned short
channel_check_interval(void)
{
  if(NETSTACK_RDC.channel_check_interval) {
    return NETSTACK_RDC.channel_check_interval();
  }
  return 0;
}

/*********************************************************************************************************
** Function name:       init
** Descriptions:        mac������init����ʵ��
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
static void
init(void)
{
  memb_init(&packet_memb);
}

/*********************************************************************************************************
  �����ṩ��tdma mac driver�Ľṹ��
*********************************************************************************************************/
const struct mac_driver tdma_mac_driver = {
  "TDMA",
  init,
  send_packet,
  input_packet,
  on,
  off,
  channel_check_interval,
};
/*********************************************************************************************************
  END FILE
*********************************************************************************************************/